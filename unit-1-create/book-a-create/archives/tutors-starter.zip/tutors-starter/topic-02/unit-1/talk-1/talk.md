Lecture

This talk has a pdf + a video with start/end times
