---
icon:
  type: uil:headphones
  color: cd344f
---   

Podcast

The HDip course team discuss approaching IT as an Adult Learner