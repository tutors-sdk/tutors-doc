---
icon:
  type: uil:archive
  color: 00979b
---   

Resource I

This is not a pdf link, but a zipped archive. If it is selected the archive will be downloaded. Use this to distributed general resources.